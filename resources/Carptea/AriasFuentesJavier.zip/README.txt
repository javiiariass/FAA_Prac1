No me di cuenta de que había que guardar los resultados del csv. Los he puesto todos pero el formato de las gráficas es distinto al del word.
En el word está todo "bien" puestecito.